package com.mycompany.domain;

public class BuyVO {

	private int buyId;
	private int buylistId;
	private int bookId;
	private int buyCnt;
	
	public int getBuyId() {
		return buyId;
	}
	public void setBuyId(int buyId) {
		this.buyId = buyId;
	}
	public int getBuylistId() {
		return buylistId;
	}
	public void setBuylistId(int buylistId) {
		this.buylistId = buylistId;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public int getBuyCnt() {
		return buyCnt;
	}
	public void setBuyCnt(int buyCnt) {
		this.buyCnt = buyCnt;
	}
}
