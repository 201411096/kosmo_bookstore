package com.mycompany.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mycompany.domain.ReviewVO;

@Repository("reviewDAO")
public class ReviewDAOImpl implements ReviewDAO{
	@Autowired
	private SqlSessionTemplate mybatis;

	@Override
	public int insertReview(ReviewVO vo) {
		int result = mybatis.insert("ReviewDAO.insertReview", vo);
		return result;
	}
	@Override
	public List<ReviewVO> selectReview(ReviewVO vo) {
		List<ReviewVO> result = mybatis.selectList("ReviewDAO.selectReview", vo);
		return result;
	}
	public ReviewVO modiSelectReview(ReviewVO vo) {
		ReviewVO review = mybatis.selectOne("ReviewDAO.modiSelectReview", vo);
		return review;
	}
	public int updateReview(ReviewVO vo) {
		int result = mybatis.update("ReviewDAO.updateReview", vo);
		return result;
	}	
}
