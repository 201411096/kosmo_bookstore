package com.mycompany.dao;

import com.mycompany.domain.BuyVO;

public interface BuyDAO {
	public int addBuy(BuyVO vo);
}
