package com.mycompany.service;

import com.mycompany.domain.BuyVO;

public interface BuyService {
	public int addBuy(BuyVO vo);
}
