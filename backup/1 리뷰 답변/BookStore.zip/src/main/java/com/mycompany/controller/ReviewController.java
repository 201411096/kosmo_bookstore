package com.mycompany.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.mycompany.domain.BookVO;
import com.mycompany.domain.BuyListVO;
import com.mycompany.domain.CustomerVO;
import com.mycompany.domain.ReviewVO;
import com.mycompany.service.BookServiceImpl;
import com.mycompany.service.ReviewServiceImpl;

@Controller
public class ReviewController {
	@Autowired
	ReviewServiceImpl reviewService;
	@Autowired
	BookServiceImpl bookService;

	// 리뷰 입력
	@RequestMapping("/productReview.do")
	public ModelAndView reviewInsert(ReviewVO vo, BookVO bookVO, HttpSession session) {
		ModelAndView mv = new ModelAndView();
		CustomerVO customer = (CustomerVO) session.getAttribute("customer");
		vo.setCustomerId(customer.getCustomerId());
		
		int result = reviewService.insertReview(vo);
		if (result == 0) {
			mv.setViewName("/login");
		}

		ReviewVO reviewVO = new ReviewVO();
		reviewVO.setBookId(vo.getBookId());

		List<ReviewVO> reviewList = (List<ReviewVO>) reviewService.selectReview(reviewVO);
		mv.addObject("review", reviewList);
		mv.setViewName("/productView");

		BookVO book = bookService.selectBook(bookVO);
		mv.addObject("priceBeforeDiscount", book.getBookSaleprice() + 3000);
		mv.addObject("info", book);

		return mv;
	}

	// 리뷰 수정 시 customerId 확인
	@RequestMapping("/modiSelectReview.do")
	public ModelAndView modiSelectReview(ReviewVO vo,BookVO bookVO, HttpSession session) {
		ModelAndView mv = new ModelAndView();
		BookVO book = bookService.selectBook(bookVO);
	     mv.addObject("priceBeforeDiscount", book.getBookSaleprice() + 3000);
	     mv.addObject("info", book);
	     
		ReviewVO review = (ReviewVO)reviewService.modiSelectReview(vo); // 수정하고 싶은 리뷰

		String rId = review.getCustomerId();// 리뷰아이디
		String sId = ((CustomerVO) session.getAttribute("customer")).getCustomerId();// 사용자 아이디
		System.out.println("rId:"+rId+",sId:"+sId);
		if (rId == null || !rId.equals(sId)) {
			mv.setViewName("/login");
		} else {
			// 리뷰 가져오기
			List<ReviewVO> reviewList = (List<ReviewVO>) reviewService.selectReview(review);
			mv.addObject("modify", review);
			mv.addObject("review", reviewList);
			mv.setViewName("/productView");
			//productView 들어갈 때 customer Reviews a태그에 class를 "active" 줘야해
		}
		return mv;
	}
	
	// 수정내용 업데이트 : 입력텍스트 받기
	@RequestMapping("/updateReview.do")
	public ModelAndView updateReview(ReviewVO vo,BookVO bookVO) {

		
		ModelAndView mv = new ModelAndView();
		BookVO book = bookService.selectBook(bookVO);
	     mv.addObject("priceBeforeDiscount", book.getBookSaleprice() + 3000);
	     mv.addObject("info", book);
		int result=reviewService.updateReview(vo);
		
		ReviewVO reviewVO = new ReviewVO();
		reviewVO.setBookId(vo.getBookId());

		List<ReviewVO> reviewList = (List<ReviewVO>) reviewService.selectReview(reviewVO);
		mv.addObject("review", reviewList);
		mv.setViewName("/productView");
		
		if(result==0) {
			mv.setViewName("/login");
		}else {
			mv.setViewName("/productView");
		}
		
		return mv;
	}

	
	
}
