
	

$(function(){
	//리뷰 버튼 연결
	$('#send-btn').click(function(){
		$('#buyreviewId').val(0);
		$('#modiform').attr("action","productReview.do");
		$('#modiform').submit();
	});
	//수정 버튼 연결
	$('#update-btn').click(function(){
//		$('#buyreviewId').val(0);
		$('#modiform').attr("action","updateReview.do");
		$('#modiform').submit();
	});
});


